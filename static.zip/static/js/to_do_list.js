// Configuração Firebase (já fornecida)
import { 
    initializeApp 
} from "https://www.gstatic.com/firebasejs/11.0.2/firebase-app.js";
import {
    getFirestore,
    collection,
    addDoc,
    getDocs,
    updateDoc,
    deleteDoc,
    doc,
} from "https://www.gstatic.com/firebasejs/11.0.2/firebase-firestore.js";

// Configuração do Firebase
const firebaseConfig = {
    apiKey: "AIzaSyCrZgHlPVX59zM68ENmAyXogc3JmoTU5rE",
    authDomain: "tentando-eed5d.firebaseapp.com",
    projectId: "tentando-eed5d",
    storageBucket: "tentando-eed5d.appspot.com",
    messagingSenderId: "103578231381",
    appId: "1:103578231381:web:485a8e94f53e8087e92adc",
    measurementId: "G-V3BFLM3V3X",
};

// Inicializa o Firebase e o Firestore
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

document.addEventListener("DOMContentLoaded", async () => {
    const listaTarefas = document.getElementById("listaTarefas");
    const modal = new bootstrap.Modal(document.getElementById("editTaskModal"));
    const taskCollection = collection(db, "tasks");

    let tarefas = [];
    let tarefaEditando = null;

    // Função para carregar tarefas do Firestore
    const carregarTarefas = async () => {
        const snapshot = await getDocs(taskCollection);
        tarefas = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
        renderizarTarefas();
    };

    // Função para renderizar as tarefas na interface
    const renderizarTarefas = () => {
        listaTarefas.innerHTML = tarefas
            .map(
                (tarefa) => `
          <li class="list-group-item ${getClassePrioridade(tarefa.prioridade)}">
            <span>${tarefa.nome} (${tarefa.prioridade})</span>
            <div>
              <button class="btn btn-sm btn-warning editar-btn" data-id="${tarefa.id}" ${tarefa.concluida ? "disabled" : ""}>Editar</button>
              <button class="btn btn-sm btn-primary concluir-btn" data-id="${tarefa.id}" ${tarefa.concluida ? "disabled" : ""}>Concluir</button>
              <button class="btn btn-sm btn-danger remover-btn" data-id="${tarefa.id} " ${tarefa.concluida ? "disabled" : ""}>Remover</button>
            </div>
          </li>`
            )
            .join("");

        document.querySelectorAll(".editar-btn").forEach((btn) =>
            btn.addEventListener("click", () => abrirModalEdicao(btn.dataset.id))
        );
        document.querySelectorAll(".concluir-btn").forEach((btn) =>
            btn.addEventListener("click", () => concluirTarefa(btn.dataset.id))
        );
        document.querySelectorAll(".remover-btn").forEach((btn) =>
            btn.addEventListener("click", () => removerTarefa(btn.dataset.id))
        );
    };

    // Função para adicionar uma nova tarefa
    const adicionarTarefa = async (nome, prioridade) => {
        await addDoc(taskCollection, { nome, prioridade, concluida: false });
        await carregarTarefas();
    };

    // Função para abrir o modal de edição de tarefa
    const abrirModalEdicao = (id) => {
        tarefaEditando = tarefas.find((tarefa) => tarefa.id === id);
        document.getElementById("taskNameModal").value = tarefaEditando.nome;
        document.getElementById("taskPriorityModal").value = tarefaEditando.prioridade;
        modal.show();
    };

    // Função para salvar as alterações de edição
    const salvarEdicao = async () => {
        const novoNome = document.getElementById("taskNameModal").value;
        const novaPrioridade = document.getElementById("taskPriorityModal").value;

        if (tarefaEditando) {
            const tarefaDoc = doc(taskCollection, tarefaEditando.id);
            await updateDoc(tarefaDoc, { nome: novoNome, prioridade: novaPrioridade });
            modal.hide();
            await carregarTarefas();
        }
    };

    // Função para concluir uma tarefa
    const concluirTarefa = async (id) => {
        const tarefaDoc = doc(taskCollection, id);
        await updateDoc(tarefaDoc, { concluida: true });
        await carregarTarefas();
    };

    // Função para remover uma tarefa
    const removerTarefa = async (id) => {
        const tarefaDoc = doc(taskCollection, id);
        await deleteDoc(tarefaDoc);
        await carregarTarefas();
    };

    // Função para determinar a classe de prioridade da tarefa
    const getClassePrioridade = (prioridade) => {
        switch (prioridade) {
            case "alta":
                return "list-group-item-danger";
            case "media":
                return "list-group-item-warning";
            case "baixa":
                return "list-group-item-success";
            default:
                return "";
        }
    };

    // Adiciona o evento ao botão de salvar edição
    document.getElementById("saveTaskChanges").addEventListener("click", salvarEdicao);

    // Adiciona o evento ao botão de adicionar tarefa
    document.getElementById("addTaskButton").addEventListener("click", async () => {
        const nome = document.getElementById("taskName").value;
        const prioridade = document.getElementById("taskPriority").value;
        if (nome && prioridade) {
            await adicionarTarefa(nome, prioridade);
        }
        document.getElementById("taskName").value = "";
    });

    // Adiciona eventos aos botões de ordenação
    document.getElementById("ordenarAlfabetico").addEventListener("click", () => {
        tarefas.sort((a, b) => a.nome.localeCompare(b.nome));
        renderizarTarefas();
    });

    document.getElementById("ordenarPrioridadeAlta").addEventListener("click", () => {
        tarefas.sort((a, b) => (a.prioridade === "alta" ? -1 : 1));
        renderizarTarefas();
    });

    document.getElementById("ordenarPrioridadeBaixa").addEventListener("click", () => {
        tarefas.sort((a, b) => (a.prioridade === "baixa" ? -1 : 1));
        renderizarTarefas();
    });

    // Adiciona evento ao botão de remover todas as tarefas
    document.getElementById("botaoRemoverTodas").addEventListener("click", async () => {
        const promises = tarefas.map((tarefa) => removerTarefa(tarefa.id));
        await Promise.all(promises);
        await carregarTarefas();
    });

    // Adiciona evento ao botão de remover tarefas concluídas
    document.getElementById("botaoRemoverTodasConcluidas").addEventListener("click", async () => {
        const tarefasConcluidas = tarefas.filter((tarefa) => tarefa.concluida);
        const promises = tarefasConcluidas.map((tarefa) => removerTarefa(tarefa.id));
        await Promise.all(promises);
        await carregarTarefas();
    });

    // Carrega as tarefas ao iniciar a página
    await carregarTarefas();
});